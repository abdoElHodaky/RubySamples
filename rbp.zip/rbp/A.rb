begin
       ''' A=[1,2,3,4,5]
        if A[0]==1
            ++A[0]
            print(A)    
        end  
        '''
    begin
            
            i=0
            while i<=5 
                print(i,"\t")
                i+=1
            end
            
        
        
    end
    puts(__FILE__)
end


  