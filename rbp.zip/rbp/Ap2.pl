@A=(1,0,3,8,-1,5,-5,-15);
sub dessrt {
	my(@array)=@_;
	for (my $i = 0; $i < @array.length; $i++) {
		for (my $j = $i+1; $j <@array.length; $j++) {	
				if (@array[$j]>@array[$i]) {
					$tmp=@array[$j];
					@array[$j]=@array[$i];
					@array[$i]=$tmp;
				}
				}
		}
return @array
}
sub ascsrt {
	my(@array)=@_;
	for (my $i = 0; $i < @array.length; $i++) {
		for (my $j = $i+1; $j < @array.length; $j++) {
			if (@array[$j]<@array[$i]) {
				$tmp=@array[$j];
				@array[$j]=@array[$i];
				@array[$i]=$tmp;
			}
	}
}
return @array;
}
@array=&ascsrt(@A);
@array2=&dessrt(@A);
for (my $var = 0; $var < @array.length; $var++) {
		print"\n",$array[$var],"\n";
}
for (my $var = 0; $var < @array2.length; $var++) {
		print"\n",$array2[$var],"\n";
}