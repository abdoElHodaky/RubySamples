using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
public class Matrix
{
    private List<List<double>>_matrix;
    static int rMul=0;
    static Matrix result;
    public dynamic this[params int[] inputs]
    {
        get
        {
            if(inputs[0]!=-1&& inputs.Count()==1){
                return Matrix.GetRows(matrix,inputs[0]);
            }else if(inputs[0]==-1){
                return Matrix.GetCols(matrix,inputs[1]);
            }else if(inputs[0]>-1&&inputs[1]>-1){
                return this[-1,inputs[1]][inputs[0]];
            }else return null;
        }
        set
        {
            if(inputs[0]!=-1 && inputs.Count()==1){
                Matrix.EditRows<double>(matrix,inputs[0],value);
            }else if(inputs[0]!=-1 && inputs[1]!=-1){
               matrix[inputs[0]][inputs[1]] = value; 
            }else{
                Matrix.EditCols<double>(matrix,inputs[1],value);
            }
        }
    }
    public Matrix(){
        
    }
    public Matrix(List<double>list){
        this.matrix=Matrix.LtoMatrix(list,Matrix.row(list));
        result=new Matrix();
    }
    public List<List<double>> matrix{
        get{
            return this._matrix;
        }
        set{
            this._matrix=value;
        }
    }
    internal static List<List<T>> build<T>(int rows=0){
        int i=0;
        var matrix= new List<List<T>>();
        for(;i<rows;i++){
            matrix.Add(new List<T>());
        }
        return matrix;
        
    }
    internal static List<List<T>>LtoMatrix<T>(List<T>list,int rows){
        var matrix= Matrix.build<T>(rows);
        for(int i=0;i<list.Count;i++){
            matrix[i / rows].Add(list[i]);
        }
        if(matrix[matrix.Count-1].Count==0)matrix.RemoveAt(matrix.Count-1);
        return matrix;
        
    }
	internal static int row<T>(List<T>list){
		return (int)Math.Ceiling(Math.Sqrt(list.Count));
	}
    internal static List<T>GetRows<T>(List<List<T>>matrix,int nrows=0){
        return matrix[nrows];
    }
    internal static List<T>GetCols<T>(List<List<T>>matrix,int ncols=0){
        var cols= new List<T>();
        for(int i=0;i<matrix.Count;i++){
            cols.Add(Matrix.GetRows(matrix,i)[ncols]);
        }
        return cols;
    }
    internal static void EditRows<T>(List<List<T>>matrix,int nrows,List<T>newlist){
        matrix[nrows]=newlist;
        return;
    }
    internal static void EditCols<T>(List<List<T>>matrix,int ncols,List<T>newlist){
        int i=0;
        var cols= Matrix.GetCols<T>(matrix,ncols);
        for(;i<cols.Count;i++){
            matrix[i][ncols]=newlist[i];
        }
        return;
    }
    internal static void MulByScalar(List<List<double>>matrix,double scalar,int vector,
    bool row=false){
        if(vector==-1){
            for(int i=0;i<matrix.Count;i++){
                MulByScalar(matrix,scalar,i,true);
            }
        }else{
            var res=(row==true)?(Matrix.GetRows(matrix,vector)):(Matrix.GetCols(matrix,vector));
            int i=0;
            for(;i<res.Count;i++){
                res[i]*=scalar;
            }
            if(row==false)Matrix.EditCols(matrix,vector,res);
        }
    }
    internal static void AddScalar(List<List<double>>matrix,double scalar,int vector,bool reverse=false
    ,bool row=false){
        if(vector==-1){
            for(int i=0;i<matrix.Count;i++){
                MulByScalar(matrix,scalar,i,true);
            }
        }else{
            var res=(row==true)?(Matrix.GetRows(matrix,vector)):(Matrix.GetCols(matrix,vector));
            int i=0;
            for(;i<res.Count;i++){
                if(reverse==true)
                {
                    var diff=res[i]-scalar;
                    res[i]=diff<0?(diff/-1):diff;
                    
                }
                else
                {
                    res[i]+=scalar;
                    
                }
            }
            if(row==false)Matrix.EditCols(matrix,vector,res);
        }
    }
    internal static List<double>Mx(List<List<double>>matrix,int vector,bool row=false){
        if(vector==-1){
            var res=new List<double>();
            int count=row==false?matrix[0].Count:matrix.Count;
            for(int i=0;i<count;i++){
                res.Add(Mx(matrix,i,row)[0]);
            }
            return res;
        }
        else
        {
            var maxies=new List<double>();
            if(row==true){
                maxies.Add(Matrix.GetRows<double>(matrix,vector).Max());
            }else{
                 maxies.Add(Matrix.GetCols<double>(matrix,vector).Max());
                }    
            return maxies;
        }
    }
    internal static List<double>Mn(List<List<double>>matrix,int vector,bool row=false){
       if(vector==-1){
            var res=new List<double>();
            int count=row==false?matrix[0].Count:matrix.Count;
            for(int i=0;i<count;i++){
                res.Add(Mn(matrix,i,row)[0]);
            }
            return res;
        }
       else
        {   var mines=new List<double>();
            if(row==true){
                mines.Add(Matrix.GetRows<double>(matrix,vector).Min());
            }else{
                 mines.Add(Matrix.GetCols<double>(matrix,vector).Min());
                }    
            return mines;
            
        }
    }
    internal static List<List<T>>GetTranspose<T>(List<List<T>>matrix){
       var res=new List<List<T>>();
            for(int i=0;i<matrix[0].Count;i++){
               res.Add(Matrix.GetCols<T>(matrix,i));
            }
            return res;
    }
    internal static List<List<int>>GetIndex(List<List<double>>matrix,double item){
        var index=new List<List<int>>();
        int i=0;
        for(;i<matrix[0].Count;i++){
            var cols=Matrix.GetCols(matrix,i);
            if(cols.Contains(item)){
                index.Add(new List<int>(){cols.IndexOf(item),i});
            }
        }
        return index;
    }
    internal static List<List<T>> GetMinor<T>(List<List<T>>matrix,int row,int col){
        var rMatrix=new List<T>();
        var r=row;
        var c=col;
        for(int i=0;i<matrix.Count;i++){
           for(int j=0;j<matrix[i].Count;j++){
               if(c!=j && r!=i)rMatrix.Add(matrix[i][j]);
            } 
        }
        return Matrix.LtoMatrix(rMatrix,Matrix.row(rMatrix));
    }
    internal static double GetDet(List<List<double>>matrix,int i=0){
        if(matrix.Count==1)
        return matrix[0][0];
        else if(matrix.Count==2)
        return (matrix[1][1]*matrix[0][0])-(matrix[1][0]*matrix[0][1]);
        else if(matrix.Count==3)
        return (matrix[0][0] * matrix[1][1] * matrix[2][2]
                +matrix[0][1] * matrix[1][ 2] * matrix[2][0] + 
                matrix[0][2] * matrix[1][0] * matrix[2][1] -
                (matrix[0][2] * matrix[1][1] * matrix[2][0] + 
                matrix[0][0] * matrix[1][ 2] * matrix[2][1] + 
                matrix[0][1] * matrix[1][0] * matrix[2][2]));
        else{
                var d=0.0;
                for(int j=0;j<matrix.Count;j++)
                {
                    var sign=Math.Pow(-1,(i+j));
                    d+=GetDet(Matrix.GetMinor(matrix,i,j))*sign*Matrix.GetRows(matrix,i)[j];
                    
                }
                return d;
        }
    }
    internal static List<List<double>>GetCofactors(List<List<double>>matrix){
        int i=0;
        var res=new List<double>();
        for(;i<matrix.Count;i++){
			int j=0;
			for(;j<matrix[i].Count;j++)
            {
				var minor=Matrix.GetMinor<double>(matrix,i,j);
				res.Add(Matrix.GetDet(minor)*Math.Pow(-1,(i+j)));
			}
        }
        return Matrix.LtoMatrix(res,Matrix.row(res));
    }
    internal static List<List<double>> GetAdJ(List<List<double>>matrix){
        if(matrix.Count==2){
            var tmp=matrix[0][0];
			matrix[0][0]=matrix[1][1];
			matrix[1][1]=tmp;
			matrix[0][1]*=(-1);
			matrix[1][0]*=(-1);
        }
        else
        {
            matrix=Matrix.GetTranspose<double>(Matrix.GetCofactors(matrix));
        }
        return matrix;
    }
    internal static List<List<double>> GetInverse(List<List<double>>matrix){
        var det=Matrix.GetDet(matrix);
        if(det!=0){
            Matrix.MulByScalar(Matrix.GetAdJ(matrix),Math.Pow(det,-1),-1);
        }
        return matrix;
    }
    public static Matrix operator+(Matrix m,Matrix m2){
        var res=m2.matrix;
        var resultM=Matrix.build<double>(res.Count);
        int i=0;
        for(;i<res.Count;i++){
            var r1=Matrix.GetRows(m.matrix,i);
            var r2=Matrix.GetRows(m2.matrix,i);
            for(int j=0;j<r1.Count;j++){
                resultM[i].Add(r1[j]+r2[j]);
            }
        }
        result.matrix=resultM;
        return result;
    }
    public static  Matrix operator-(Matrix m,Matrix m2){
        var res=m2.matrix;
        var resultM=Matrix.build<double>(res.Count);
        int i=0;
        for(;i<res.Count;i++){
            var r1=Matrix.GetRows(m.matrix,i);
            var r2=Matrix.GetRows(m2.matrix,i);
            for(int j=0;j<r1.Count;j++){
              resultM[i].Add(r1[j]-r2[j]);
            }
        }
        result.matrix=resultM;
        return result;
    }
    public static  Matrix operator*(Matrix m,Matrix m2){
        var res=m2.matrix;
        var r=new List<double>();
        int i=0;
        for(;i<res.Count;i++){
            for(int j=0;j<res[i].Count;j++){
                var sum=0.0;
               for(int k=0;k<res.Count;k++){
                  // sum+=Matrix.GetRows(m.matrix,i)[k]*Matrix.GetRows(m.matrix,k)[j];
                  sum+=rMul==1?m[j,k]*m2[i,k]:m[i,k]*m2[k,j];
               }
               r.Add(sum);
            }
        }
        result.matrix=Matrix.LtoMatrix(r,Matrix.row(r));
        return result;
    }
    public static  Matrix operator*(Matrix m,int pow){
        var r=m;
        int n=pow<0?(pow/-1):pow;
        if(n==1)
        return (pow<0)?!m:m;
        else
        r=m*(m*(n-1));
        return(pow<0)?!r:r;
    }
    public static Matrix operator/(Matrix m,Matrix m2){
        return m*(!m2);
    }
    public static Matrix operator!(Matrix m){
        result.matrix=Matrix.GetInverse(m.matrix);
        return result;
    }
    /*internal static public bool operator==(Matrix m,Matrix m2){
        int i=0;
        var equal=false;
        for(;i<m.matrix.Count;){
            var r1=Matrix.GetRows(m.matrix,i);
            var r2=Matrix.GetRows(m2.matrix,i);
            int j=0;
            for(;j<r1.Count;){
                if(r1.Contains(r2[j])){
                    equal=true;
                }else equal=false;
                j++;
            }
            i++;
        }
        return equal;
    }
    internal static public bool operator!=(Matrix m,Matrix m2){
        int i=0;
        var nequal=true;
        for(;i<m.matrix.Count;){
            var r1=Matrix.GetRows(m.matrix,i);
            var r2=Matrix.GetRows(m2.matrix,i);
            int j=0;
            for(;j<r1.Count;){
                if(!r1.Contains(r2[j])){
                    nequal=true;
                }else nequal=false;
                j++;
            }
            i++;
        }
        return nequal;
    }*/
    
    public Matrix Clone(bool useoperator=false){
        if(useoperator){
            return this*1;
        }
        else{
            var m=this;
            return m;
        }
    }
    internal static List<int>GetSize<T>(List<List<T>> matrix){
        return new List<int>(){matrix.Count,matrix[0].Count};
    }
    public static void Main()
    {
        var list=new List<double>()/*{50,0,-8,-10,12,64,-15,66,12}*/{1,2,3,4};
        //var matrix=Matrix.LtoMatrix<double>(list,Matrix.row(list));
        var m= new Matrix(list);
        m[1,0]=7;
        Console.Write(m[-1,0][1]);
        //Console.Write(Regret(matrix)+"\n");
        //Console.Write(Regret(matrix,false)+"\n");
        
    }/*
    static double Regret(List<List<double>>matrix,bool cost=true){
        int i=0;
        for(;i<matrix.Count;)
        {
            var max=cost?Matrix.Mn(matrix,i)[0]:Matrix.Mx(matrix,i)[0];
            Matrix.AddScalar(matrix,max,i,true);
            i++;
            
        }
        return Matrix.Mx(matrix,-1,true).Min();
    }
    static double EVPI(List<List<double>>matrix,List<double>probs){
        var tmpMatrix=matrix;
        int i=0;
        for(;i<probs.Count;){
            var cols=Matrix.GetCols(tmpMatrix,i);
            Matrix.MulByScalar(tmpMatrix,probs[i],i);
            i++;
        }
        i=0;
        var res=new List<double>();
        for(;i<tmpMatrix.Count;i++){
            res.Add(Matrix.GetRows(tmpMatrix,i).Sum());
        }
        var Ev= res.Max();
        var sum=0.0;
        i=0;
        for(;i<probs.Count;){
            var cols=Matrix.GetCols(matrix,i);
            var max=cols.Max();
            max*=probs[i];
            sum+=max;
            i++;
        }
        return sum-Ev;
    }
    static void Neib(List<List<double>>matrix,int col,bool cost=true){
        var items=Matrix.GetCols(matrix,col);
        var res=new List<double>();
        var prevCol=col-1;
        items.ForEach((b)=>{
            var index=new List<int>(){items.IndexOf(b),col};
            var rows=Matrix.GetRows(matrix,index[0]);
            var _cols=Matrix.GetCols(matrix,prevCol);
            if(index[0]%2==1 || Math.Floor(Math.Sqrt(matrix.Count))==index[0] ){
                if(index[0]==rows.Count-1){
                    _cols=_cols.GetRange(index[0]-1,index[0]+1);
                }else{
                     _cols=_cols.GetRange(index[0]-1,index[0]+2);
                }
            }
            else{
                _cols=_cols.GetRange(index[0],2);
            }
            var max=(cost==false)?_cols.Max():_cols.Min();
            res.Add(b+max);
        });
        Matrix.EditCols(matrix,prevCol,res);
    }*/
}