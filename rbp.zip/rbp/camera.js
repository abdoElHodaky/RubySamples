public var objectToFollow:GameObject ;
public var speed:float= 2.0f;
private var camerax:float;
private var cameray:float;
function Update(){
	var interpolation:float = speed * Time.deltaTime;
	var position:Vector3 = transform.position;
    position.y = Mathf.Lerp(transform.position.y, objectToFollow.transform.position.y, interpolation);
    position.x = Mathf.Lerp(transform.position.x, objectToFollow.transform.position.x, interpolation);
    transform.position = position;
}
function LateUpdate(){
	    camerax = Camera.main.transform.position.x;
        cameray = Camera.main.transform.position.y;
        BG.transform.position = Vector3(camerax, cameray, transform.position.z);
        mountain.transform.position =Vector3(camerax, cameray, transform.position.z);
}