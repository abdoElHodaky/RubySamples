private var reg:Rigidbody2D ;
public var coin:AudioClip;
public var charac:AudioClip;
private var speed:int = 10;
public var Sky:GameObject ;
public var ground:GameObject ;
public var mountain:GameObject ;
var count:int=0;
function Start()
    {
    	reg=GetComponent.<Rigidbody2D>();

    }
function Update(){
	var x:int = 0;
    var y:int = 0;
	if (Input.GetKey("right"))
        {
            x = speed;
            transform.localScale =  Vector3(2, 2, 1);
            Sky.transform.position += Vector3.left * speed * Time.deltaTime;
            mountain.transform.position += Vector3.left * speed * Time.deltaTime;
            ground.transform.position += Vector3.left * speed * Time.deltaTime;
            AudioSource.PlayClipPoint(charc,tranform.postion);
        }
        else if (Input.GetKey("left"))
        {
            x = -speed;
            transform.localScale =  Vector3(-2, 2, 1);
            Sky.transform.position += Vector3.right * speed * Time.deltaTime;
            mountain.transform.position += Vector3.right * speed * Time.deltaTime;
            ground.transform.position += Vector3.right * speed * Time.deltaTime;
            AudioSource.PlayClipPoint(charc,tranform.postion);
        }
        reg.AddForce(Vector2(x, y));

}
function OnCollision2DEnter(obj:Collider2D){
	if (obj.tag=="target") {
		Destroy(gameObject);
		AudioSource.PlayClipPoint(coin,gameObject.tranform.postion);
		GUI.Label (Rect (Screen.width-gameObject.transform.position.x,Screen.height-gameObject.transform.position.y, 30, 20),`${count++} coins`);
	}
}