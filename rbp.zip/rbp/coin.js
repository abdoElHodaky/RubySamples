public var ac:AudioClip;
var count:int=0;
function OnTrigger2DEnter(obj:Collider2D){
	if (obj.tag=="target") {
		Destroy(gameObject);
		AudioSource.PlayClipPoint(ac,tranform.postion);
		GUI.Label (Rect (Screen.width-gameObject.transform.position.x,Screen.height-gameObject.transform.position.y, 30, 20),`${count++} coins`);
	}
}