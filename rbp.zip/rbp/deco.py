def decorator(func):
         '''def function_wrapper():
                   print("A")
                   ()'''
         return func
def decorator(func):
         return func
@decorator
def dis(x):
         m=lambda x:x*2
         print(m(x))
dis(5)
