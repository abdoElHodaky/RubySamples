A={"A"=>"B"}
#puts A
puts(%q{Abdo});