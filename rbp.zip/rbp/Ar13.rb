a=[8, 4, 6, 2, 6, 4, 7, 9, 5, 8]
a.sort()
for i in (0...(a.length-1))
	if a[i+1]==a[i]
		print i
	else
		print i
	end
end