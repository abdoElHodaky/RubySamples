/**
 * We declare a package-level function main which returns Unit and takes
 * an Array of strings as a parameter. Note that semicolons are optional.
 */
open class Person(){
    open fun func():String{
        return "Person";
    }
}
open class Std(var name:String,var age:Number):Person(){
    open var Name:String=""
     get()=this.name
     set(value){
        field=value;
    }
     open fun sum(other:Std):Std{
        other.name=this.Name;
        other.age=this.age;
        return other
    }
    override fun func():String{
        return "Std";
    }
}
class Employee(name:String,age:Number,var dep:String):Std(name,age){
      override fun sum(other:Std):Std{
        other.name=this.Name;
        other.age=this.age;
        return other
    }
    override fun func():String{
        return "Employee";
    }
}
data class C(val n:Int,val a:String){
    
}
fun<T>func(b:()->T):T{
    try{
        return b()
    }
    finally{
        
    }
}
fun main(args: Array<String>) {
    
    //val std=Std("Abdo",20);
    //std.age=22;
    //std.name="Ali";
   // println(std.age.toString() +"\n"+std.name);
  /*var arr=arrayOf(1,2,3,4,5,6,7,8,9);
    with(arr,{println(arr)})*/
   // val e= Employee("Ali",23,"it");
    //println(e.age);
   /* var a=object{
        var name:String="Ali";
        var dep:String="IT";
    };
    println(a.name);
    */
    /*var e= Employee("Ali",25,"IT");
    var std=Std("Ahmed",20);
    println(std.sum(Std("Mos",30)).Name);
    println(e.sum(Employee("Ahmed",20,"IT")).Name);*/
    //var sum:(Int,Int)->Int={a,b->a+b};
   // println(sum(5,5));
   //var e:Std= Employee("Ali",25,"IT");
   //println(e.func());
   /*var c:C=C(2,"3")
    println(c);*/
    func{
         var c:C=C(2,"3")
      println(c);
    }
}